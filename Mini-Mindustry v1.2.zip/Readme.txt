Python Mini-Mindustry v1.2

1. Перед запуском игры установи Python https://www.python.org/downloads/
2. Скачай библиотеку Pygame-ce (Откройте cmd и впишите pip install Pygame-ce)

Version 1.2
-Добавлены новые турели
-Добавлены новые типы врагов
-Добавлены новые команды
-Полностью удалены конвейеры 